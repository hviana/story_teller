AMR Guidelines
==============

[amr.md](amr.md) is a living document that explains how to translate English into Abstract Meaning Representation (AMR).

See also the [AMR Dictionary](https://www.isi.edu/~ulf/amr/lib/amr-dict.html), which provides details on the treatment of specific words and constructions, and the usage of specific roles and concepts.
